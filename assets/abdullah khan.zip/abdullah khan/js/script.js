document.getElementById("registerForm").addEventListener("submit", function(event) {
    // Prevent form submission
    event.preventDefault();
  
    // Clear any previous errors
    clearErrors();
  
    // Get form field values
    const firstName = document.getElementById("firstName").value.trim();
    const lastName = document.getElementById("lastName").value.trim();
    const email = document.getElementById("email").value.trim();
    const phone = document.getElementById("phone").value.trim();
    const password = document.getElementById("password").value.trim();
  
    let isValid = true;
  
    // Validate first name (required)
    if (firstName === "") {
      document.getElementById("firstNameError").innerText = "First name is required.";
      isValid = false;
    }
  
    // Validate last name (required)
    if (lastName === "") {
      document.getElementById("lastNameError").innerText = "Last name is required.";
      isValid = false;
    }
  
    // Validate email (must be in correct format)
    if (!validateEmail(email)) {
      document.getElementById("emailError").innerText = "Please enter a valid email address.";
      isValid = false;
    }
  
    // Validate phone number (must be numeric and valid format)
    if (!validatePhone(phone)) {
      document.getElementById("phoneError").innerText = "Please enter a valid phone number.";
      isValid = false;
    }
  
    // Validate password (must be at least 8 characters)
    if (password.length < 8) {
      document.getElementById("passwordError").innerText = "Password must be at least 8 characters long.";
      isValid = false;
    }
  
    // If the form is valid, print the values in the console as an object
    if (isValid) {
      const formData = {
        firstName: firstName,
        lastName: lastName,
        email: email,
        phone: phone,
        password: password
      };
  
      console.log(formData); // Print the form data as an object in the console
  
      // Proceed with form submission or other logic if needed
      // alert("Form submitted successfully!");
    }
  });
  
  // Function to clear all error messages
  function clearErrors() {
    document.getElementById("firstNameError").innerText = "";
    document.getElementById("lastNameError").innerText = "";
    document.getElementById("emailError").innerText = "";
    document.getElementById("phoneError").innerText = "";
    document.getElementById("passwordError").innerText = "";
  }
  
  // Helper function to validate email format
  function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(String(email).toLowerCase());
  }
  
  // Helper function to validate phone number format (basic validation)
  function validatePhone(phone) {
    const re = /^[0-9]{10}$/; // Adjust this regex for your preferred phone format
    return re.test(String(phone));
  }
  